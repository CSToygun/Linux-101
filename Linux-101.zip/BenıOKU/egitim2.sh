#!/bin/bash
#boşuna okumaya çalışma
#hile yapma

BLOG_NAME="AsosyalBebe"
CURRENT_DIR=$(pwd)
CONCAT_VAR="$BLOG_NAME$CURRENT_DIR"

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

readonly FLAG_51="sen" 
readonly FLAG_52="gidi"
readonly FLAG_53="akıllı"
readonly FLAG_54="bıdık"

#boşuna okumaya çalışma
#anlamazsın
#hile yapma

#boşuna okumaya çalışma
#anlamazsın

#boşuna okumaya çalışma
#anlamazsın

#boşuna okumaya çalışma
#anlamazsın

#boşuna okumaya çalışma
#anlamazsın

#boşuna okumaya çalışma
#anlamazsın



BLOG_NAME="AsosyalBebe"
CURRENT_DIR=$(pwd)
CONCAT_VAR="$BLOG_NAME$CURRENT_DIR"

#boşuna okumaya çalışma
#anlamazsın

echo "HACKED BY SAUSIBER :d "
echo "Zaaaa xd :d "
#boşuna okumaya çalışma
#anlamazsın

readonly FLAG_1="gizli" 
FLAG_2="dünya"
readonly FLAG_3="ayrıcalıktır"
readonly FLAG_4="belki ben buyum"

touch .sausiberrflag1.txt
echo "$FLAG_1" > .sausiberflag1.txt

touch .flagfake.txt
echo "b2xtYWs=" > sausiberflagfake.txt
FLAG_2="parola"
echo "$FLAG_2" > /tmp/sausiberflag2.txt

CEVAP="hacked"


#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

echo "3 flagi bosluklu olarak giriniz"
echo "CEVABINIZI GIRINIZ : "
read CEVAP

if [[ ( $CEVAP == "$FLAG_1 $FLAG_2 S4us!b3r" ) ]]; then
echo "TEBRIKLER - "
echo "Sausiber{Fl4g_L1n11x_T0rv4ld5}"
else
echo "hatali cevap. Tekrar deneyiniz :D Lol xd "
fi


#boşuna okumaya çalışma
#hile yapma


#boşuna okumaya çalışma
#hile yapma


#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

readonly FLAG_1="gizli" 
FLAG_2="dünya"
readonly FLAG_3="ayrıcalıktır"
readonly FLAG_4="belki ben buyum"

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma

#boşuna okumaya çalışma
#hile yapma









